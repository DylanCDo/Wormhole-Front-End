
const SessionJoinPage = ({ DOMAIN }) => {

    return (
    <div>
      <h1 className='leading-10'>Wormhole</h1>
      <h2 className='text-indigo-500'>The Seamless File Transfer Web App</h2>
      <div className='py-12'/>   
      <p className='session-text py-4'>Type in the expiry below</p>
      <div>
        <input
          className='rounded-md'
          placeholder='Expiry'
          type='text'
          onChange={(e) => setSessionId(e.target.value)}
        />
      </div>

      <div className='py-1'/>

      <input
        className='rounded-md'
        placeholder='Password(Empty if None)'
        type='text'

        //password doesnt do anything yet
        onChange={(e) => setSessionId(e.target.value)}
      />
      <div className='py-1'/>

      <div className='centerize' style={{ marginBottom: 50 }}>
        <button className='primary-button bg-indigo-600 text-white hover:font-bold' onClick={GoToSession}>
          Go To Session
        </button>
      </div>

      <div className='centerize'>
        <a href='/' className='primary-button button-imposter font-bold hover:font-semibold'>
          Back to main app
        </a>
      </div>
    </div>
  );
}