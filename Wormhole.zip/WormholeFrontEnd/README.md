## Table of Contents

- [Requirements](#requirements)
- [Installation](#installation)

## Requirements

- [Node.js v20.10.0](https://nodejs.org/dist/v20.10.0/node-v20.10.0-x64.msi)

## Installation

1. `npm install` in a terminal within the root directory
2. `npm run dev` in the root directory to run the frontend server